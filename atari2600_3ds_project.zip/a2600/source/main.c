/*
 * Atari 2600 emulator for the (Old) Nintendo 3DS.
 * Top screen : 160x192 TIA output scaled to 400x240 (2.5x / 1.25x = correct 2:1 pixel aspect)
 * Bottom     : ROM menu / status console
 * Audio      : 2-channel TIA mixed to mono, played through ndsp
 */
#include <3ds.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <sys/stat.h>

#include "cpu6507.h"
#include "tia.h"
#include "riot.h"
#include "memory.h"
#include "testrom.h"

#ifdef HAVE_EMBEDDED_ROM
#include "game_bin.h"
#endif

#define ROM_DIR      "sdmc:/roms/a2600"
#define MAX_ENTRIES  256
#define AUDIO_RATE   31440
#define NUM_WBUFS    4
#define FRAME_TICKS  (SYSCLOCK_ARM11 / 60)   /* one NTSC frame in system ticks */
#define MAX_SKIP     2                       /* max consecutive frames not drawn */

typedef struct {
    char name[64];
    char path[300];
    int  builtin;           /* 1 = embedded / test ROM */
} rom_entry_t;

static rom_entry_t entries[MAX_ENTRIES];
static int         num_entries;
static char        current_name[64];

static uint16_t palette[128];

/* audio */
static int         audio_ok;
static ndspWaveBuf wbuf[NUM_WBUFS];
static int16_t    *abufs;

/* switches */
static int diff0, diff1;

/* ------------------------------------------------------------------ */
/* Video                                                               */
/* ------------------------------------------------------------------ */
static void present_frame(void)
{
    u16 w, h;
    u16 *fb = (u16 *)gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &w, &h);
    static int ymap[240];
    static int xmap[400];
    static int map_init;
    if (!map_init) {
        for (int dy = 0; dy < 240; dy++) ymap[dy] = dy * 192 / 240;
        for (int dx = 0; dx < 400; dx++) xmap[dx] = dx * 160 / 400;
        map_init = 1;
    }

    int y0 = tia.first_visible;
    if (y0 + 192 > TIA_MAX_LINES) y0 = TIA_MAX_LINES - 192;

    /* The framebuffer is column-major and rotated, so each output column is one
     * source column (a 240-entry strip); neighbouring output columns often repeat
     * the same source column, so build the strip once and copy it. */
    const uint8_t *rows[240];
    for (int dy = 0; dy < 240; dy++) rows[239 - dy] = tia.fb[y0 + ymap[dy]];

    u16 col[240] __attribute__((aligned(8)));
    int prev_sx = -1;
    for (int dx = 0; dx < 400; dx++) {
        int sx = xmap[dx];
        u16 *dst = fb + dx * 240;
        if (sx != prev_sx) {
            for (int i = 0; i < 240; i++) col[i] = palette[rows[i][sx]];
            prev_sx = sx;
        }
        memcpy(dst, col, sizeof col);
    }
}

/* ------------------------------------------------------------------ */
/* Audio                                                               */
/* ------------------------------------------------------------------ */
static void audio_init(void)
{
    audio_ok = 0;
    if (R_FAILED(ndspInit())) return;       /* needs sdmc:/3ds/dspfirm.cdc */
    abufs = (int16_t *)linearAlloc(NUM_WBUFS * TIA_AUDIO_BUF * sizeof(int16_t));
    if (!abufs) { ndspExit(); return; }

    ndspSetOutputMode(NDSP_OUTPUT_MONO);
    ndspChnReset(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, AUDIO_RATE);
    ndspChnSetFormat(0, NDSP_FORMAT_MONO_PCM16);
    float mix[12] = { 0 };
    mix[0] = mix[1] = 1.0f;
    ndspChnSetMix(0, mix);

    memset(wbuf, 0, sizeof wbuf);
    for (int i = 0; i < NUM_WBUFS; i++) {
        wbuf[i].data_vaddr = abufs + i * TIA_AUDIO_BUF;
        wbuf[i].status = NDSP_WBUF_DONE;
    }
    audio_ok = 1;
}

static void audio_submit(void)
{
    if (!audio_ok || tia.an <= 0) return;
    for (int i = 0; i < NUM_WBUFS; i++) {
        if (wbuf[i].status == NDSP_WBUF_DONE || wbuf[i].status == NDSP_WBUF_FREE) {
            int16_t *dst = abufs + i * TIA_AUDIO_BUF;
            memcpy(dst, tia.abuf, tia.an * sizeof(int16_t));
            wbuf[i].data_vaddr = dst;
            wbuf[i].nsamples = tia.an;
            DSP_FlushDataCache(dst, tia.an * sizeof(int16_t));
            ndspChnWaveBufAdd(0, &wbuf[i]);
            return;
        }
    }
    /* all buffers busy: drop this frame's audio to stay in sync */
}

static void audio_stop(void)
{
    if (!audio_ok) return;
    ndspChnWaveBufClear(0);
}

/* ------------------------------------------------------------------ */
/* ROM list / loading                                                  */
/* ------------------------------------------------------------------ */
static int has_rom_ext(const char *n)
{
    const char *dot = strrchr(n, '.');
    return dot && (!strcasecmp(dot, ".bin") || !strcasecmp(dot, ".a26"));
}

static int cmp_entries(const void *a, const void *b)
{
    return strcasecmp(((const rom_entry_t *)a)->name, ((const rom_entry_t *)b)->name);
}

static void scan_roms(void)
{
    num_entries = 0;
#ifdef HAVE_EMBEDDED_ROM
    snprintf(entries[0].name, sizeof entries[0].name, "[Embedded game]");
    entries[0].builtin = 1;
    num_entries = 1;
#endif
    snprintf(entries[num_entries].name, sizeof entries[0].name, "[Built-in test ROM]");
    entries[num_entries].builtin = 2;
    num_entries++;

    mkdir("sdmc:/roms", 0777);
    mkdir(ROM_DIR, 0777);
    DIR *d = opendir(ROM_DIR);
    if (!d) return;
    int first = num_entries;
    struct dirent *e;
    while ((e = readdir(d)) && num_entries < MAX_ENTRIES) {
        if (e->d_name[0] == '.' || !has_rom_ext(e->d_name)) continue;
        rom_entry_t *r = &entries[num_entries++];
        snprintf(r->name, sizeof r->name, "%s", e->d_name);
        snprintf(r->path, sizeof r->path, ROM_DIR "/%s", e->d_name);
        r->builtin = 0;
    }
    closedir(d);
    qsort(entries + first, num_entries - first, sizeof(rom_entry_t), cmp_entries);
}

static int start_rom(const rom_entry_t *r)
{
    const uint8_t *data = NULL;
    size_t size = 0;
    uint8_t *filebuf = NULL;

    if (r->builtin == 2) {
        data = testrom_get(&size);
    }
#ifdef HAVE_EMBEDDED_ROM
    else if (r->builtin == 1) {
        data = game_bin;
        size = game_bin_size;
    }
#endif
    else {
        FILE *f = fopen(r->path, "rb");
        if (!f) { printf("\nCannot open file.\n"); return 0; }
        filebuf = (uint8_t *)malloc(40000);
        if (!filebuf) { fclose(f); return 0; }
        size = fread(filebuf, 1, 40000, f);
        fclose(f);
        data = filebuf;
    }

    int rc = cart_load(data, size);
    free(filebuf);
    if (rc != 0) {
        printf("\nUnsupported ROM size (%u bytes).\nSupported: 2K 4K 8K(F8) 16K(F6) 32K(F4)\n", (unsigned)size);
        return 0;
    }
    bus_reset();
    snprintf(current_name, sizeof current_name, "%s", r->name);
    return 1;
}

/* ------------------------------------------------------------------ */
/* Menu / status                                                       */
/* ------------------------------------------------------------------ */
static void draw_menu(int sel, int top)
{
    printf("\x1b[2J\x1b[1;1H");
    printf("  ATARI 2600 for 3DS\n");
    printf("  ROMs: sdmc:/roms/a2600/ (.bin .a26)\n");
    printf("  ----------------------------------\n");
    for (int i = top; i < num_entries && i < top + 20; i++)
        printf("%c %.36s\n", i == sel ? '>' : ' ', entries[i].name);
    printf("\x1b[28;1H  Up/Down: select   A: launch");
    printf("\x1b[29;1H  START: exit app");
}

static void draw_status(void)
{
    printf("\x1b[2J\x1b[1;1H");
    printf("  %.36s\n  Mapper: %s\n\n", current_name, cart_mapper_name());
    printf("  D-Pad/Circle : Joystick\n");
    printf("  A / B        : Fire\n");
    printf("  START        : Game Reset\n");
    printf("  SELECT       : Game Select\n");
    printf("  L            : P0 Difficulty\n");
    printf("  R            : P1 Difficulty\n");
    printf("  X            : Back to menu\n");
    printf("\x1b[14;1H  P0 diff: %c   P1 diff: %c ", diff0 ? 'A' : 'B', diff1 ? 'A' : 'B');
}

/* ------------------------------------------------------------------ */
/* Input                                                               */
/* ------------------------------------------------------------------ */
static void poll_game_input(u32 held, u32 down)
{
    circlePosition cp;
    hidCircleRead(&cp);

    uint8_t a = 0xFF;
    if ((held & KEY_DRIGHT) || cp.dx >  40) a &= ~0x80;
    if ((held & KEY_DLEFT)  || cp.dx < -40) a &= ~0x40;
    if ((held & KEY_DDOWN)  || cp.dy < -40) a &= ~0x20;
    if ((held & KEY_DUP)    || cp.dy >  40) a &= ~0x10;
    riot.swcha_in = a;

    if (down & KEY_L) diff0 ^= 1;
    if (down & KEY_R) diff1 ^= 1;
    if (down & (KEY_L | KEY_R)) {
        printf("\x1b[14;1H  P0 diff: %c   P1 diff: %c ", diff0 ? 'A' : 'B', diff1 ? 'A' : 'B');
    }

    uint8_t b = 0x3F;                       /* bit3 = colour, unused bits high */
    if (held & KEY_START)   b &= ~0x01;     /* Game Reset  */
    if (held & KEY_SELECT)  b &= ~0x02;     /* Game Select */
    if (diff0) b |= 0x40;
    if (diff1) b |= 0x80;
    riot.swchb_in = b;

    tia.inpt4 = (held & (KEY_A | KEY_B)) ? 0x00 : 0x80;
    tia.inpt5 = 0x80;
}

/* ------------------------------------------------------------------ */
int main(void)
{
    osSetSpeedupEnable(true);        /* New 3DS: 804 MHz + L2 cache (no-op on Old 3DS) */
    gfxInitDefault();
    gfxSetScreenFormat(GFX_TOP, GSP_RGB565_OES);
    gfxSetDoubleBuffering(GFX_TOP, true);
    consoleInit(GFX_BOTTOM, NULL);

    tia_build_palette(palette);
    audio_init();
    scan_roms();

    enum { ST_MENU, ST_RUN } state = ST_MENU;
    int sel = 0, top = 0;

    /* Boot straight into the first entry (embedded game if present, else the test ROM) */
    if (start_rom(&entries[0])) { state = ST_RUN; draw_status(); }
    else draw_menu(sel, top);

    int skipped = 0;
    u64 present_cost = 0;
    u64 frame_t0 = svcGetSystemTick();

    while (aptMainLoop()) {
        hidScanInput();
        u32 down = hidKeysDown();
        u32 held = hidKeysHeld();

        if (state == ST_MENU) {
            if (down & KEY_START) break;
            if (down & KEY_DDOWN) { if (sel + 1 < num_entries) sel++; }
            if (down & KEY_DUP)   { if (sel > 0) sel--; }
            if (sel < top) top = sel;
            if (sel >= top + 20) top = sel - 19;
            if (down & (KEY_DDOWN | KEY_DUP)) draw_menu(sel, top);

            if (down & KEY_A) {
                if (start_rom(&entries[sel])) { state = ST_RUN; draw_status(); frame_t0 = svcGetSystemTick(); }
            }
            gfxFlushBuffers();
            gfxSwapBuffers();
            gspWaitForVBlank();
        } else {
            if (down & KEY_X) {
                audio_stop();
                skipped = 0;
                state = ST_MENU;
                draw_menu(sel, top);
                continue;
            }
            poll_game_input(held, down);
            bus_run_frame();
            audio_submit();             /* always keep audio fed, even if the frame is skipped */

            /* If emulating this frame plus drawing it would miss the vblank, skip
             * drawing and start the next frame right away instead of dropping to 30 fps. */
            u64 emu = svcGetSystemTick() - frame_t0;
            if (emu + present_cost > FRAME_TICKS && skipped < MAX_SKIP) {
                skipped++;
            } else {
                u64 p0 = svcGetSystemTick();
                present_frame();
                gfxFlushBuffers();
                gfxSwapBuffers();
                present_cost = svcGetSystemTick() - p0;
                gspWaitForVBlank();
                skipped = 0;
            }
            frame_t0 = svcGetSystemTick();
        }
    }

    if (audio_ok) { ndspChnWaveBufClear(0); ndspExit(); linearFree(abufs); }
    gfxExit();
    return 0;
}
