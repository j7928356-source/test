#!/usr/bin/env python3
"""Generate placeholder HOME-menu assets with the Python standard library only:
   assets/icon.png   48x48
   assets/banner.png 256x128
   assets/audio.wav  ~1 s, 16-bit PCM mono (bannertool needs <= 3 s)
Replace them with your own art/sound any time (keep the same sizes/format)."""
import math, os, struct, wave, zlib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
os.makedirs(OUT, exist_ok=True)

def write_png(path, w, h, pixel):
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(pixel(x, y))
    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))   # 8-bit RGB
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    png += chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)

STRIPES = [(228, 60, 60), (240, 150, 40), (240, 220, 60), (70, 190, 90), (60, 130, 230), (150, 90, 220)]

def icon_px(x, y):
    if x < 2 or y < 2 or x >= 46 or y >= 46:
        return (240, 240, 240)
    if 10 <= y < 38:
        return STRIPES[(y - 10) * len(STRIPES) // 28]
    return (24, 24, 32)

def banner_px(x, y):
    base = (20 + y // 8, 20 + y // 8, 36 + y // 6)
    if 40 <= y < 88:
        return STRIPES[(x * len(STRIPES) // 256 + (y - 40) // 8) % len(STRIPES)]
    return base

# Never overwrite art you've already put in assets/
if not os.path.exists(os.path.join(OUT, "icon.png")):
    write_png(os.path.join(OUT, "icon.png"), 48, 48, icon_px)
if not os.path.exists(os.path.join(OUT, "banner.png")):
    write_png(os.path.join(OUT, "banner.png"), 256, 128, banner_px)

with wave.open(os.path.join(OUT, "audio.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
    frames = bytearray()
    for i in range(22050):                      # 1 second
        t = i / 22050.0
        freq = 440 if t < 0.5 else 660
        env = min(1.0, t * 40) * max(0.0, 1.0 - t) * 0.4
        frames += struct.pack("<h", int(32767 * env * math.sin(2 * math.pi * freq * t)))
    w.writeframes(bytes(frames))
print("Wrote assets/icon.png, assets/banner.png, assets/audio.wav")
