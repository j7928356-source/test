# Atari 2600 for (Old) Nintendo 3DS

## Build
1. Install devkitPro with `3ds-dev` (devkitARM + libctru):
   `sudo dkp-pacman -S 3ds-dev`   (Windows: use the devkitPro installer)
2. `export DEVKITPRO=/opt/devkitpro` and `export DEVKITARM=$DEVKITPRO/devkitARM`
3. In this folder run `make`  ->  `a2600.3dsx` (+ `.smdh`)
4. Copy the `.3dsx` to `sdmc:/3ds/` and launch via the Homebrew Launcher.

## ROMs
* With no ROM embedded, the emulator boots a built-in homebrew test ROM
  (colour bars, playfield border, a player bar you move with Left/Right; A = colour change).
* Put your own `.bin` / `.a26` files in `sdmc:/roms/a2600/`, press X in-game for the menu.
* To embed your own legally obtained ROM at build time: copy it to `data/game.bin`
  and run `make clean && make`. It becomes the boot game.
* Supported: 2K, 4K, F8 (8K); F6 (16K) and F4 (32K) as a bonus.

## Controls
D-Pad / Circle Pad = joystick, A or B = fire, START = Game Reset, SELECT = Game Select,
L / R = P0 / P1 difficulty, X = back to menu (START exits from the menu).

## Audio
Needs `sdmc:/3ds/dspfirm.cdc` (dump with DSP1). Without it the emulator runs silent.

## Build a .cia (HOME Menu install)
1. Get `makerom` (3DSGuy/Project_CTR releases) and `bannertool`; put both on your PATH
   (e.g. `/opt/devkitpro/tools/bin`).
2. `python3 tools/make_assets.py` (only if `assets/` is missing or you want to regenerate placeholders)
3. `make cia`  ->  `a2600.cia` and `a2600.3dsx`
4. Install the `.cia` with FBI (requires custom firmware). Title ID: `000400000FA26000`.
