#ifndef RIOT_H
#define RIOT_H
#include <stdint.h>

/* MOS 6532 RIOT: 128 bytes RAM, 2 I/O ports, interval timer */
typedef struct {
    uint8_t ram[128];
    uint8_t swcha_in, swchb_in;      /* external inputs (joystick / console switches) */
    uint8_t swcha_out, ddra, ddrb;
    int intim, interval, sub, underflow;
    uint8_t timint;
} riot_t;

extern riot_t riot;

void    riot_reset(void);
uint8_t riot_read(uint16_t addr);
void    riot_write(uint16_t addr, uint8_t v);

/* Called once per CPU cycle */
static inline void riot_tick(void)
{
    if (!riot.underflow) {
        if (--riot.sub <= 0) {
            riot.sub = riot.interval;
            if (riot.intim == 0) {
                riot.underflow = 1;
                riot.timint = 1;
                riot.intim = 0xFF;
            } else {
                riot.intim--;
            }
        }
    } else {
        riot.intim = (riot.intim - 1) & 0xFF;
    }
}
#endif
