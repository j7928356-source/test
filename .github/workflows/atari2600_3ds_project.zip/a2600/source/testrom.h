#ifndef TESTROM_H
#define TESTROM_H
#include <stdint.h>
#include <stddef.h>
/* Tiny homebrew 4K test ROM, assembled at runtime (no copyrighted data).
 * Shows scrolling colour bars, a playfield border and a joystick-movable
 * player bar (left/right). Fire changes its colour. */
const uint8_t *testrom_get(size_t *size);
#endif
