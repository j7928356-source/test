/*
 * MOS 6507 core. Every bus cycle (including dummy cycles) calls bus_tick(),
 * so TIA writes land on the correct colour clock ("racing the beam").
 */
#include "cpu6507.h"
#include "memory.h"

cpu6507_t cpu;

static inline uint8_t rd(uint16_t a)            { bus_tick(); return bus_read(a); }
static inline void    wr(uint16_t a, uint8_t v) { bus_tick(); bus_write(a, v); }
static inline void    dummy(void)               { bus_tick(); }
static inline uint8_t fetch(void)               { uint8_t v = rd(cpu.pc); cpu.pc++; return v; }

static inline void push(uint8_t v) { wr(0x100 | cpu.sp, v); cpu.sp--; }
static inline uint8_t pull(void)   { cpu.sp++; return rd(0x100 | cpu.sp); }

#define SETNZ(v) do { uint8_t _v = (uint8_t)(v); \
    cpu.p = (uint8_t)((cpu.p & ~(F_N | F_Z)) | (_v & 0x80) | (_v ? 0 : F_Z)); } while (0)

/* ---------- addressing modes (return effective address) ---------- */
static uint16_t ea_zp(void)  { return fetch(); }
static uint16_t ea_zpx(void) { uint8_t a = fetch(); dummy(); return (uint8_t)(a + cpu.x); }
static uint16_t ea_zpy(void) { uint8_t a = fetch(); dummy(); return (uint8_t)(a + cpu.y); }
static uint16_t ea_abs(void) { uint16_t lo = fetch(); uint16_t hi = fetch(); return lo | (hi << 8); }
static uint16_t ea_absi(uint8_t idx, int always)
{
    uint16_t lo = fetch(); uint16_t hi = fetch();
    uint16_t base = lo | (hi << 8), ea = (uint16_t)(base + idx);
    if (always || ((base ^ ea) & 0xFF00)) dummy();
    return ea;
}
static uint16_t ea_indx(void)
{
    uint8_t z = fetch(); dummy(); z += cpu.x;
    uint16_t lo = rd(z); uint16_t hi = rd((uint8_t)(z + 1));
    return lo | (hi << 8);
}
static uint16_t ea_indy(int always)
{
    uint8_t z = fetch();
    uint16_t lo = rd(z); uint16_t hi = rd((uint8_t)(z + 1));
    uint16_t base = lo | (hi << 8), ea = (uint16_t)(base + cpu.y);
    if (always || ((base ^ ea) & 0xFF00)) dummy();
    return ea;
}

/* ---------- ALU helpers ---------- */
static void adc(uint8_t m)
{
    unsigned c = cpu.p & F_C;
    unsigned a = cpu.a;
    if (cpu.p & F_D) {
        unsigned bin = a + m + c;
        int al = (int)(a & 0x0F) + (m & 0x0F) + (int)c;
        if (al >= 0x0A) al = ((al + 0x06) & 0x0F) + 0x10;
        unsigned r = (a & 0xF0) + (m & 0xF0) + (unsigned)al;
        cpu.p &= ~(F_N | F_V | F_Z | F_C);
        if (!(bin & 0xFF)) cpu.p |= F_Z;
        if (r & 0x80) cpu.p |= F_N;
        if (~(a ^ m) & (a ^ r) & 0x80) cpu.p |= F_V;
        if (r >= 0xA0) r += 0x60;
        if (r >= 0x100) cpu.p |= F_C;
        cpu.a = (uint8_t)r;
    } else {
        unsigned s = a + m + c;
        cpu.p &= ~(F_C | F_V);
        if (s > 0xFF) cpu.p |= F_C;
        if (~(a ^ m) & (a ^ s) & 0x80) cpu.p |= F_V;
        cpu.a = (uint8_t)s;
        SETNZ(cpu.a);
    }
}

static void sbc(uint8_t m)
{
    if (cpu.p & F_D) {
        int a = cpu.a, c = cpu.p & F_C;
        int bin = a - m - (1 - c);
        int al = (a & 0x0F) - (m & 0x0F) + c - 1;
        if (al < 0) al = ((al - 0x06) & 0x0F) - 0x10;
        int r = (a & 0xF0) - (m & 0xF0) + al;
        if (r < 0) r -= 0x60;
        cpu.p &= ~(F_N | F_V | F_Z | F_C);
        if (!(bin & 0xFF)) cpu.p |= F_Z;
        if (bin & 0x80) cpu.p |= F_N;
        if ((a ^ m) & (a ^ bin) & 0x80) cpu.p |= F_V;
        if (bin >= 0) cpu.p |= F_C;
        cpu.a = (uint8_t)r;
    } else {
        adc((uint8_t)~m);
    }
}

static void cmp(uint8_t r, uint8_t m)
{
    uint8_t t = (uint8_t)(r - m);
    cpu.p = (uint8_t)((cpu.p & ~F_C) | (r >= m ? F_C : 0));
    SETNZ(t);
}

static void bit(uint8_t m)
{
    cpu.p &= ~(F_N | F_V | F_Z);
    cpu.p |= (m & (F_N | F_V));
    if (!(cpu.a & m)) cpu.p |= F_Z;
}

static uint8_t op_asl(uint8_t v) { cpu.p = (uint8_t)((cpu.p & ~F_C) | (v >> 7)); v <<= 1; SETNZ(v); return v; }
static uint8_t op_lsr(uint8_t v) { cpu.p = (uint8_t)((cpu.p & ~F_C) | (v & 1)); v >>= 1; SETNZ(v); return v; }
static uint8_t op_rol(uint8_t v) { uint8_t c = cpu.p & F_C; cpu.p = (uint8_t)((cpu.p & ~F_C) | (v >> 7)); v = (uint8_t)((v << 1) | c); SETNZ(v); return v; }
static uint8_t op_ror(uint8_t v) { uint8_t c = cpu.p & F_C; cpu.p = (uint8_t)((cpu.p & ~F_C) | (v & 1)); v = (uint8_t)((v >> 1) | (c << 7)); SETNZ(v); return v; }
static uint8_t op_dec(uint8_t v) { v--; SETNZ(v); return v; }
static uint8_t op_inc(uint8_t v) { v++; SETNZ(v); return v; }

static void branch(int cond)
{
    int8_t off = (int8_t)fetch();
    if (cond) {
        dummy();
        uint16_t old = cpu.pc;
        cpu.pc = (uint16_t)(cpu.pc + off);
        if ((old ^ cpu.pc) & 0xFF00) dummy();
    }
}

/* ---------- opcode case generators ---------- */
#define ALU_READ(base, STMT) \
    case (base) + 0x00: { uint8_t m = rd(ea_indx());       STMT; break; } \
    case (base) + 0x04: { uint8_t m = rd(ea_zp());         STMT; break; } \
    case (base) + 0x08: { uint8_t m = fetch();             STMT; break; } \
    case (base) + 0x0C: { uint8_t m = rd(ea_abs());        STMT; break; } \
    case (base) + 0x10: { uint8_t m = rd(ea_indy(0));      STMT; break; } \
    case (base) + 0x14: { uint8_t m = rd(ea_zpx());        STMT; break; } \
    case (base) + 0x18: { uint8_t m = rd(ea_absi(cpu.y,0));STMT; break; } \
    case (base) + 0x1C: { uint8_t m = rd(ea_absi(cpu.x,0));STMT; break; }

#define RMW(base, FUNC) \
    case (base) + 0x00: { uint16_t a = ea_zp();             uint8_t v = rd(a); dummy(); wr(a, FUNC(v)); break; } \
    case (base) + 0x10: { uint16_t a = ea_zpx();            uint8_t v = rd(a); dummy(); wr(a, FUNC(v)); break; } \
    case (base) + 0x08: { uint16_t a = ea_abs();            uint8_t v = rd(a); dummy(); wr(a, FUNC(v)); break; } \
    case (base) + 0x18: { uint16_t a = ea_absi(cpu.x, 1);   uint8_t v = rd(a); dummy(); wr(a, FUNC(v)); break; }

void cpu_reset(void)
{
    cpu.a = cpu.x = cpu.y = 0;
    cpu.sp = 0xFD;
    cpu.p = F_U | F_I;
    cpu.pc = (uint16_t)(bus_read(0x1FFC) | (bus_read(0x1FFD) << 8));
}

void cpu_step(void)
{
    uint8_t op = fetch();

    switch (op) {
    /* ---- loads / logic / arithmetic ---- */
    ALU_READ(0x01, cpu.a |= m;  SETNZ(cpu.a))                 /* ORA */
    ALU_READ(0x21, cpu.a &= m;  SETNZ(cpu.a))                 /* AND */
    ALU_READ(0x41, cpu.a ^= m;  SETNZ(cpu.a))                 /* EOR */
    ALU_READ(0x61, adc(m))                                    /* ADC */
    ALU_READ(0xA1, cpu.a = m;   SETNZ(cpu.a))                 /* LDA */
    ALU_READ(0xC1, cmp(cpu.a, m))                             /* CMP */
    ALU_READ(0xE1, sbc(m))                                    /* SBC */

    /* ---- STA ---- */
    case 0x81: { uint16_t a = ea_indx();          wr(a, cpu.a); break; }
    case 0x85: { uint16_t a = ea_zp();            wr(a, cpu.a); break; }
    case 0x8D: { uint16_t a = ea_abs();           wr(a, cpu.a); break; }
    case 0x91: { uint16_t a = ea_indy(1);         wr(a, cpu.a); break; }
    case 0x95: { uint16_t a = ea_zpx();           wr(a, cpu.a); break; }
    case 0x99: { uint16_t a = ea_absi(cpu.y, 1);  wr(a, cpu.a); break; }
    case 0x9D: { uint16_t a = ea_absi(cpu.x, 1);  wr(a, cpu.a); break; }

    /* ---- STX / STY ---- */
    case 0x86: { uint16_t a = ea_zp();  wr(a, cpu.x); break; }
    case 0x96: { uint16_t a = ea_zpy(); wr(a, cpu.x); break; }
    case 0x8E: { uint16_t a = ea_abs(); wr(a, cpu.x); break; }
    case 0x84: { uint16_t a = ea_zp();  wr(a, cpu.y); break; }
    case 0x94: { uint16_t a = ea_zpx(); wr(a, cpu.y); break; }
    case 0x8C: { uint16_t a = ea_abs(); wr(a, cpu.y); break; }

    /* ---- LDX / LDY ---- */
    case 0xA2: cpu.x = fetch();                        SETNZ(cpu.x); break;
    case 0xA6: cpu.x = rd(ea_zp());                    SETNZ(cpu.x); break;
    case 0xB6: cpu.x = rd(ea_zpy());                   SETNZ(cpu.x); break;
    case 0xAE: cpu.x = rd(ea_abs());                   SETNZ(cpu.x); break;
    case 0xBE: cpu.x = rd(ea_absi(cpu.y, 0));          SETNZ(cpu.x); break;
    case 0xA0: cpu.y = fetch();                        SETNZ(cpu.y); break;
    case 0xA4: cpu.y = rd(ea_zp());                    SETNZ(cpu.y); break;
    case 0xB4: cpu.y = rd(ea_zpx());                   SETNZ(cpu.y); break;
    case 0xAC: cpu.y = rd(ea_abs());                   SETNZ(cpu.y); break;
    case 0xBC: cpu.y = rd(ea_absi(cpu.x, 0));          SETNZ(cpu.y); break;

    /* ---- CPX / CPY / BIT ---- */
    case 0xE0: cmp(cpu.x, fetch());       break;
    case 0xE4: cmp(cpu.x, rd(ea_zp()));   break;
    case 0xEC: cmp(cpu.x, rd(ea_abs()));  break;
    case 0xC0: cmp(cpu.y, fetch());       break;
    case 0xC4: cmp(cpu.y, rd(ea_zp()));   break;
    case 0xCC: cmp(cpu.y, rd(ea_abs()));  break;
    case 0x24: bit(rd(ea_zp()));          break;
    case 0x2C: bit(rd(ea_abs()));         break;

    /* ---- shifts / inc / dec (memory) ---- */
    RMW(0x06, op_asl)
    RMW(0x26, op_rol)
    RMW(0x46, op_lsr)
    RMW(0x66, op_ror)
    RMW(0xC6, op_dec)
    RMW(0xE6, op_inc)

    /* ---- accumulator shifts ---- */
    case 0x0A: dummy(); cpu.a = op_asl(cpu.a); break;
    case 0x2A: dummy(); cpu.a = op_rol(cpu.a); break;
    case 0x4A: dummy(); cpu.a = op_lsr(cpu.a); break;
    case 0x6A: dummy(); cpu.a = op_ror(cpu.a); break;

    /* ---- register ops ---- */
    case 0xAA: dummy(); cpu.x = cpu.a; SETNZ(cpu.x); break;   /* TAX */
    case 0x8A: dummy(); cpu.a = cpu.x; SETNZ(cpu.a); break;   /* TXA */
    case 0xA8: dummy(); cpu.y = cpu.a; SETNZ(cpu.y); break;   /* TAY */
    case 0x98: dummy(); cpu.a = cpu.y; SETNZ(cpu.a); break;   /* TYA */
    case 0xBA: dummy(); cpu.x = cpu.sp; SETNZ(cpu.x); break;  /* TSX */
    case 0x9A: dummy(); cpu.sp = cpu.x; break;                /* TXS */
    case 0xE8: dummy(); cpu.x++; SETNZ(cpu.x); break;         /* INX */
    case 0xC8: dummy(); cpu.y++; SETNZ(cpu.y); break;         /* INY */
    case 0xCA: dummy(); cpu.x--; SETNZ(cpu.x); break;         /* DEX */
    case 0x88: dummy(); cpu.y--; SETNZ(cpu.y); break;         /* DEY */

    /* ---- flags ---- */
    case 0x18: dummy(); cpu.p &= ~F_C; break;
    case 0x38: dummy(); cpu.p |=  F_C; break;
    case 0x58: dummy(); cpu.p &= ~F_I; break;
    case 0x78: dummy(); cpu.p |=  F_I; break;
    case 0xB8: dummy(); cpu.p &= ~F_V; break;
    case 0xD8: dummy(); cpu.p &= ~F_D; break;
    case 0xF8: dummy(); cpu.p |=  F_D; break;
    case 0xEA: dummy(); break;                                /* NOP */

    /* ---- stack ---- */
    case 0x48: dummy(); push(cpu.a); break;                               /* PHA */
    case 0x08: dummy(); push(cpu.p | F_B | F_U); break;                   /* PHP */
    case 0x68: dummy(); dummy(); cpu.a = pull(); SETNZ(cpu.a); break;     /* PLA */
    case 0x28: dummy(); dummy(); cpu.p = (uint8_t)((pull() & ~F_B) | F_U); break; /* PLP */

    /* ---- branches ---- */
    case 0x10: branch(!(cpu.p & F_N)); break;
    case 0x30: branch( (cpu.p & F_N)); break;
    case 0x50: branch(!(cpu.p & F_V)); break;
    case 0x70: branch( (cpu.p & F_V)); break;
    case 0x90: branch(!(cpu.p & F_C)); break;
    case 0xB0: branch( (cpu.p & F_C)); break;
    case 0xD0: branch(!(cpu.p & F_Z)); break;
    case 0xF0: branch( (cpu.p & F_Z)); break;

    /* ---- jumps / subroutines ---- */
    case 0x4C: cpu.pc = ea_abs(); break;
    case 0x6C: {
        uint16_t p = ea_abs();
        uint16_t lo = rd(p);
        uint16_t hi = rd((uint16_t)((p & 0xFF00) | ((p + 1) & 0x00FF)));  /* NMOS page-wrap bug */
        cpu.pc = lo | (hi << 8);
        break;
    }
    case 0x20: {                                                  /* JSR */
        uint16_t lo = fetch();
        dummy();
        push((uint8_t)(cpu.pc >> 8));
        push((uint8_t)(cpu.pc & 0xFF));
        uint16_t hi = fetch();
        cpu.pc = lo | (hi << 8);
        break;
    }
    case 0x60: {                                                  /* RTS */
        dummy(); dummy();
        uint16_t lo = pull();
        uint16_t hi = pull();
        dummy();
        cpu.pc = (uint16_t)((lo | (hi << 8)) + 1);
        break;
    }
    case 0x40: {                                                  /* RTI */
        dummy(); dummy();
        cpu.p = (uint8_t)((pull() & ~F_B) | F_U);
        uint16_t lo = pull();
        uint16_t hi = pull();
        cpu.pc = lo | (hi << 8);
        break;
    }
    case 0x00: {                                                  /* BRK */
        fetch();
        push((uint8_t)(cpu.pc >> 8));
        push((uint8_t)(cpu.pc & 0xFF));
        push(cpu.p | F_B | F_U);
        cpu.p |= F_I;
        uint16_t lo = rd(0x1FFE);
        uint16_t hi = rd(0x1FFF);
        cpu.pc = lo | (hi << 8);
        break;
    }

    /* ---- undocumented opcodes: treated as 2-cycle NOPs ---- */
    default: dummy(); break;
    }
}
