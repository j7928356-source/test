/* System bus: 13-bit address decode, cartridge mappers, and the master clock. */
#include <stdlib.h>
#include <string.h>
#include "memory.h"
#include "cpu6507.h"
#include "tia.h"
#include "riot.h"

static struct {
    uint8_t *rom;
    size_t   size;
    int      banks;       /* number of 4K banks (1 for 2K/4K carts) */
    int      bank;
    int      hotspot;     /* first bank-switch address (0 = none) */
    const char *name;
} cart;

int cart_load(const uint8_t *data, size_t size)
{
    int banks = 1, hotspot = 0;
    const char *name;
    switch (size) {
    case 2048:  name = "2K";        break;
    case 4096:  name = "4K";        break;
    case 8192:  name = "F8 (8K)";   banks = 2; hotspot = 0x1FF8; break;
    case 16384: name = "F6 (16K)";  banks = 4; hotspot = 0x1FF6; break;
    case 32768: name = "F4 (32K)";  banks = 8; hotspot = 0x1FF4; break;
    default: return -1;
    }
    uint8_t *copy = (uint8_t *)malloc(size);
    if (!copy) return -1;
    memcpy(copy, data, size);
    free(cart.rom);
    cart.rom = copy; cart.size = size; cart.banks = banks;
    cart.hotspot = hotspot; cart.name = name;
    cart.bank = banks - 1;
    return 0;
}

const char *cart_mapper_name(void) { return cart.name ? cart.name : "none"; }

static inline void check_hotspot(uint16_t a)
{
    if (cart.hotspot && a >= cart.hotspot && a < cart.hotspot + cart.banks)
        cart.bank = a - cart.hotspot;
}

uint8_t bus_read(uint16_t addr)
{
    addr &= 0x1FFF;
    if (addr & 0x1000) {                         /* A12: cartridge */
        if (!cart.rom) return 0xEA;
        check_hotspot(addr);
        if (cart.size == 2048) return cart.rom[addr & 0x7FF];
        return cart.rom[cart.bank * 4096 + (addr & 0xFFF)];
    }
    if (!(addr & 0x80)) return tia_read(addr);   /* A7=0: TIA */
    if (addr & 0x200)   return riot_read(addr);  /* A9=1: RIOT I/O + timer */
    return riot.ram[addr & 0x7F];                /* RIOT RAM */
}

void bus_write(uint16_t addr, uint8_t v)
{
    addr &= 0x1FFF;
    if (addr & 0x1000) { check_hotspot(addr); return; }
    if (!(addr & 0x80)) { tia_write(addr, v); return; }
    if (addr & 0x200)   { riot_write(addr, v); return; }
    riot.ram[addr & 0x7F] = v;
}

/* One CPU cycle = 3 colour clocks = 1 RIOT tick. WSYNC halts the CPU (RDY low)
 * until the beam reaches the start of the next scanline. */
void bus_tick(void)
{
    if (tia.wsync) {
        while (tia.hpos != 0) { tia_clocks(3); riot_tick(); }
        tia.wsync = 0;
    }
    tia.hpos += 3;
    tia.aclk += 3;
    if (tia.hpos >= TIA_CLOCKS_LINE || tia.aclk >= 114) tia_post_advance();
    riot_tick();
}

void bus_reset(void)
{
    tia_reset();
    riot_reset();
    if (cart.rom) cart.bank = cart.banks - 1;
    cpu_reset();
}

void bus_run_frame(void)
{
    tia.frame_ready = 0;
    tia.an = 0;
    while (!tia.frame_ready) cpu_step();
}
