#ifndef TIA_H
#define TIA_H
#include <stdint.h>

#define TIA_WIDTH         160
#define TIA_MAX_LINES     312
#define TIA_CLOCKS_LINE   228
#define TIA_HBLANK        68
#define TIA_AUDIO_BUF     1024

typedef struct {
    int cnt, out, d31, d3;
    uint8_t p4, p5;
    uint16_t p9;
} tia_audio_ch_t;

typedef struct {
    /* registers */
    uint8_t  vsync, vblank, nusiz[2], colup[2], colupf, colubk, ctrlpf, refp[2];
    uint8_t  pf[3];
    uint64_t pf40;                      /* decoded playfield: bit n = 4-pixel block n */
    uint8_t  grp[2], grp_old[2], enam[2], enabl, enabl_old;
    uint8_t  hmp[2], hmm[2], hmbl, vdelp[2], vdelbl, resmp[2];
    int      ppos[2], mpos[2], bpos;    /* object start positions (0..159) */
    uint8_t  cx[8];                     /* collision latches, indexed like CXM0P..CXPPMM */
    uint8_t  inpt4, inpt5;              /* fire buttons, bit7 = 0 when pressed */

    /* beam state */
    int hpos;                           /* colour clock within line, 0..227 */
    int rpos;                           /* pixels rendered up to this clock */
    int line;                           /* current scanline (-1 = just after VSYNC) */
    int wsync, frame_ready, hmove_blank, first_visible, fv_cur;

    /* video: palette index (colour>>1) per pixel */
    uint8_t fb[TIA_MAX_LINES][TIA_WIDTH];

    /* audio */
    uint8_t audc[2], audf[2], audv[2];
    tia_audio_ch_t ach[2];
    int aclk;
    int16_t abuf[TIA_AUDIO_BUF];
    int an;
    float dc_x, dc_y;
} tia_t;

extern tia_t tia;

void    tia_reset(void);
void    tia_write(uint16_t reg, uint8_t v);
uint8_t tia_read(uint16_t reg);
void    tia_render_to(int clock);       /* draw pixels up to the given colour clock */
void    tia_clocks(int n);              /* advance n colour clocks */
void    tia_post_advance(void);         /* handle line / audio boundaries after hpos+=n */
void    tia_build_palette(uint16_t *rgb565_128);
#endif
