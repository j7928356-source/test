#include <string.h>
#include "riot.h"

riot_t riot;

void riot_reset(void)
{
    memset(&riot, 0, sizeof riot);
    riot.swcha_in = 0xFF;
    riot.swchb_in = 0x3F;
    riot.interval = 1024;
    riot.sub = 1024;
    riot.intim = 0xFF;
}

uint8_t riot_read(uint16_t addr)
{
    if (!(addr & 4)) {
        switch (addr & 3) {
        case 0: return (riot.swcha_in & ~riot.ddra) | (riot.swcha_out & riot.ddra);
        case 1: return riot.ddra;
        case 2: return riot.swchb_in;
        default: return riot.ddrb;
        }
    }
    if (addr & 1)                       /* INSTAT */
        return riot.timint ? 0x80 : 0x00;
    riot.timint = 0;                    /* INTIM read clears the flag */
    return (uint8_t)riot.intim;
}

void riot_write(uint16_t addr, uint8_t v)
{
    if (addr & 0x10) {                  /* TIM1T / TIM8T / TIM64T / T1024T */
        static const int div[4] = { 1, 8, 64, 1024 };
        riot.interval = div[addr & 3];
        riot.sub = riot.interval;
        riot.intim = v;
        riot.underflow = 0;
        riot.timint = 0;
        return;
    }
    switch (addr & 3) {
    case 0: riot.swcha_out = v; break;
    case 1: riot.ddra = v; break;
    case 3: riot.ddrb = v; break;
    default: break;
    }
}
