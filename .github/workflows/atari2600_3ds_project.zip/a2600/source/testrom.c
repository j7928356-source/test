#include <string.h>
#include "testrom.h"

#define BASE 0xF000
static uint8_t rom[4096];
static int n;
static int built;

static void B(int v)             { rom[n++] = (uint8_t)v; }
static void I1(int op, int v)    { B(op); B(v); }
static void I2(int op, int a)    { B(op); B(a & 255); B(a >> 8); }
static int  PC(void)             { return BASE + n; }
static void BR(int op, int tgt)  { B(op); B((tgt - (BASE + n + 1)) & 255); }
static int  BRF(int op)          { B(op); B(0); return n - 1; }
static void PATCH(int idx)       { rom[idx] = (uint8_t)((BASE + n) - (BASE + idx + 1)); }

static void build(void)
{
    n = 0;
    memset(rom, 0, sizeof rom);

    B(0x78); B(0xD8);                 /* SEI, CLD            */
    I1(0xA2, 0xFF); B(0x9A);          /* LDX #$FF, TXS       */
    I1(0xA9, 0x00);                   /* LDA #0              */
    int clr = PC();
    I1(0x95, 0x00); B(0xCA); BR(0xD0, clr);   /* clear zero page */
    I1(0xA9, 0x06); I1(0x85, 0x81);   /* xpos = 6            */

    int top = PC();
    /* VSYNC: 3 lines */
    I1(0xA9, 0x02); I1(0x85, 0x00);
    I1(0x85, 0x02); I1(0x85, 0x02); I1(0x85, 0x02);
    I1(0xA9, 0x00); I1(0x85, 0x00);
    I1(0xA9, 0x02); I1(0x85, 0x01);   /* VBLANK on */
    I1(0x85, 0x02);                   /* WSYNC (ends line 3) */

    /* line 4: joystick, every 4th frame */
    I1(0xA5, 0x80); I1(0x29, 0x03);
    int skipj = BRF(0xD0);
    I2(0xAD, 0x0280); I1(0x29, 0x80); int f1 = BRF(0xD0); I1(0xE6, 0x81); PATCH(f1);   /* right */
    I2(0xAD, 0x0280); I1(0x29, 0x40); int f2 = BRF(0xD0); I1(0xC6, 0x81); PATCH(f2);   /* left  */
    I1(0xA5, 0x81); I1(0xC9, 0x01); int f3 = BRF(0xB0); I1(0xA9, 0x01); I1(0x85, 0x81); PATCH(f3);
    I1(0xA5, 0x81); I1(0xC9, 0x0D); int f4 = BRF(0x90); I1(0xA9, 0x0C); I1(0x85, 0x81); PATCH(f4);
    PATCH(skipj);
    I1(0x85, 0x02);                   /* WSYNC */

    /* line 5: object setup */
    I1(0xA9, 0x1E); I1(0x85, 0x08);   /* COLUPF */
    I1(0xA9, 0xF0); I1(0x85, 0x0D);   /* PF0 border */
    I1(0xA9, 0x01); I1(0x85, 0x0A);   /* CTRLPF mirror */
    I1(0xA9, 0xFF); I1(0x85, 0x1B);   /* GRP0 */
    I1(0xA9, 0x9A); I1(0x24, 0x0C);   /* LDA #$9A ; BIT INPT4 */
    int nf = BRF(0x30); I1(0xA9, 0x44); PATCH(nf);   /* BMI skip ; LDA #$44 (fire) */
    I1(0x85, 0x06);                   /* COLUP0 */
    I1(0x85, 0x02);                   /* WSYNC */

    /* 32 blank lines */
    I1(0xA2, 0x20);
    int vb = PC(); I1(0x85, 0x02); B(0xCA); BR(0xD0, vb);
    I1(0x85, 0x02);                   /* WSYNC (ends line 38) */

    /* line 39: horizontal position of P0 via delay loop */
    I1(0xA6, 0x81);
    int lp = PC(); B(0xCA); BR(0xD0, lp);
    I1(0x85, 0x10);                   /* RESP0 */
    I1(0x85, 0x02);                   /* WSYNC */

    /* 192 visible lines */
    I1(0xA9, 0x00); I1(0x85, 0x01);   /* VBLANK off */
    I1(0xA2, 0xC0);
    int vis = PC();
    B(0x8A); B(0x18); I1(0x65, 0x80); I1(0x85, 0x09); I1(0x85, 0x02); B(0xCA); BR(0xD0, vis);

    /* 30 overscan lines */
    I1(0xA9, 0x02); I1(0x85, 0x01);
    I1(0xA2, 0x1E);
    int os = PC(); I1(0x85, 0x02); B(0xCA); BR(0xD0, os);

    I1(0xE6, 0x80);                   /* frame++ */
    I2(0x4C, top);                    /* JMP top */

    rom[0xFFC] = 0x00; rom[0xFFD] = 0xF0;
    rom[0xFFE] = 0x00; rom[0xFFF] = 0xF0;
}

const uint8_t *testrom_get(size_t *size)
{
    if (!built) { build(); built = 1; }
    *size = sizeof rom;
    return rom;
}
