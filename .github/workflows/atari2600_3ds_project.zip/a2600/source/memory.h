#ifndef MEMORY_H
#define MEMORY_H
#include <stdint.h>
#include <stddef.h>

/* Cartridge: 2K, 4K, F8 (8K), plus F6 (16K) / F4 (32K) as a bonus. */
int         cart_load(const uint8_t *data, size_t size);  /* 0 = ok, -1 = unsupported */
const char *cart_mapper_name(void);

void    bus_reset(void);                 /* resets TIA, RIOT, bank, CPU */
uint8_t bus_read(uint16_t addr);
void    bus_write(uint16_t addr, uint8_t v);
void    bus_tick(void);                  /* advance exactly one CPU cycle (3 colour clocks) */
void    bus_run_frame(void);             /* run until the TIA finishes a frame */
#endif
