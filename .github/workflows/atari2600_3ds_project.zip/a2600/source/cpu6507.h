#ifndef CPU6507_H
#define CPU6507_H
#include <stdint.h>

#define F_C 0x01
#define F_Z 0x02
#define F_I 0x04
#define F_D 0x08
#define F_B 0x10
#define F_U 0x20
#define F_V 0x40
#define F_N 0x80

typedef struct {
    uint8_t  a, x, y, sp, p;
    uint16_t pc;
} cpu6507_t;

extern cpu6507_t cpu;

void cpu_reset(void);
void cpu_step(void);   /* executes one instruction; every bus cycle calls bus_tick() */
#endif
