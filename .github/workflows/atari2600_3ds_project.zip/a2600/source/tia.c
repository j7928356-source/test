/*
 * Television Interface Adaptor.
 * Rendering is lazy but exact: pixels are generated up to the current colour
 * clock immediately before any register write / collision read, and at the end
 * of each scanline, so mid-line register changes ("racing the beam") work.
 */
#include <string.h>
#include <math.h>
#include "tia.h"

tia_t tia;

/* copy bitmasks (units of 8 pixels): modes 0..4 and 6; 5 and 7 are single wide copies */
static const uint16_t copymask16[8] = { 0x001, 0x005, 0x011, 0x015, 0x101, 0x001, 0x111, 0x001 };

static inline int wrap160(int v) { v %= 160; return v < 0 ? v + 160 : v; }

/* ------------------------------------------------------------------ */
/* Palette (NTSC, generated from YIQ)                                  */
/* ------------------------------------------------------------------ */
void tia_build_palette(uint16_t *pal)
{
    for (int i = 0; i < 128; i++) {
        int hue = (i >> 3) & 15, lum = i & 7;
        float y = 0.08f + (float)lum * 0.125f;
        float ii = 0, q = 0;
        if (hue) {
            float ang = (-44.0f + (float)(hue - 1) * 24.0f) * 3.14159265f / 180.0f;
            ii = 0.27f * cosf(ang);
            q  = 0.27f * sinf(ang);
        }
        float r = y + 0.956f * ii + 0.621f * q;
        float g = y - 0.272f * ii - 0.647f * q;
        float b = y - 1.106f * ii + 1.703f * q;
        int ri = (int)(r * 255.0f), gi = (int)(g * 255.0f), bi = (int)(b * 255.0f);
        if (ri < 0) { ri = 0; }
        if (ri > 255) { ri = 255; }
        if (gi < 0) { gi = 0; }
        if (gi > 255) { gi = 255; }
        if (bi < 0) { bi = 0; }
        if (bi > 255) { bi = 255; }
        pal[i] = (uint16_t)(((ri >> 3) << 11) | ((gi >> 2) << 5) | (bi >> 3));
    }
}

/* ------------------------------------------------------------------ */
/* Playfield decode                                                    */
/* ------------------------------------------------------------------ */
static void rebuild_pf(void)
{
    uint32_t left = 0;
    int k = 0;
    for (int b = 4; b < 8; b++) left |= (uint32_t)((tia.pf[0] >> b) & 1) << k++;
    for (int b = 7; b >= 0; b--) left |= (uint32_t)((tia.pf[1] >> b) & 1) << k++;
    for (int b = 0; b < 8; b++) left |= (uint32_t)((tia.pf[2] >> b) & 1) << k++;
    uint32_t right = left;
    if (tia.ctrlpf & 1) {
        right = 0;
        for (int b = 0; b < 20; b++) right |= ((left >> b) & 1u) << (19 - b);
    }
    tia.pf40 = (uint64_t)left | ((uint64_t)right << 20);
}

/* ------------------------------------------------------------------ */
/* Object pixel tests                                                  */
/* ------------------------------------------------------------------ */
static inline int player_on(int i, int x)
{
    uint8_t g = tia.vdelp[i] ? tia.grp_old[i] : tia.grp[i];
    if (!g) return 0;
    int off = x - tia.ppos[i]; if (off < 0) off += 160;
    int nz = tia.nusiz[i] & 7, bit;
    if (nz == 5)      { if (off >= 16) return 0; bit = off >> 1; }
    else if (nz == 7) { if (off >= 32) return 0; bit = off >> 2; }
    else {
        if (off >= 72) return 0;
        if (!((copymask16[nz] >> (off >> 3)) & 1)) return 0;
        bit = off & 7;
    }
    return (tia.refp[i] & 8) ? ((g >> bit) & 1) : ((g >> (7 - bit)) & 1);
}

static inline int missile_on(int i, int x)
{
    if (!(tia.enam[i] & 2) || (tia.resmp[i] & 2)) return 0;
    int off = x - tia.mpos[i]; if (off < 0) off += 160;
    int w = 1 << ((tia.nusiz[i] >> 4) & 3);
    int nz = tia.nusiz[i] & 7;
    if (nz == 5 || nz == 7) return off < w;
    if (off >= 72) return 0;
    if (!((copymask16[nz] >> (off >> 3)) & 1)) return 0;
    return (off & 7) < w;
}

static inline int ball_on(int x)
{
    uint8_t e = tia.vdelbl ? tia.enabl_old : tia.enabl;
    if (!(e & 2)) return 0;
    int off = x - tia.bpos; if (off < 0) off += 160;
    return off < (1 << ((tia.ctrlpf >> 4) & 3));
}

static inline uint8_t draw_pixel(int x)
{
    int pf = (int)((tia.pf40 >> (x >> 2)) & 1);
    int p0 = player_on(0, x), p1 = player_on(1, x);
    int m0 = missile_on(0, x), m1 = missile_on(1, x);
    int bl = ball_on(x);

    if (p0 | p1 | m0 | m1 | bl) {
        if (m0) {
            if (p1) tia.cx[0] |= 0x80;
            if (p0) tia.cx[0] |= 0x40;
            if (pf) tia.cx[4] |= 0x80;
            if (bl) tia.cx[4] |= 0x40;
            if (m1) tia.cx[7] |= 0x40;
        }
        if (m1) {
            if (p0) tia.cx[1] |= 0x80;
            if (p1) tia.cx[1] |= 0x40;
            if (pf) tia.cx[5] |= 0x80;
            if (bl) tia.cx[5] |= 0x40;
        }
        if (p0) {
            if (pf) tia.cx[2] |= 0x80;
            if (bl) tia.cx[2] |= 0x40;
            if (p1) tia.cx[7] |= 0x80;
        }
        if (p1) {
            if (pf) tia.cx[3] |= 0x80;
            if (bl) tia.cx[3] |= 0x40;
        }
        if (bl && pf) tia.cx[6] |= 0x80;
    }

    if ((tia.vblank & 2) || (tia.hmove_blank && x < 8)) return 0;

    uint8_t pfcol = tia.colupf;
    if (tia.ctrlpf & 2) pfcol = (x < 80) ? tia.colup[0] : tia.colup[1];

    uint8_t c;
    if (tia.ctrlpf & 4) {
        if (pf)             c = pfcol;
        else if (bl)        c = tia.colupf;
        else if (p0 | m0)   c = tia.colup[0];
        else if (p1 | m1)   c = tia.colup[1];
        else                c = tia.colubk;
    } else {
        if (p0 | m0)        c = tia.colup[0];
        else if (p1 | m1)   c = tia.colup[1];
        else if (bl)        c = tia.colupf;
        else if (pf)        c = pfcol;
        else                c = tia.colubk;
    }
    return (uint8_t)(c >> 1);
}

void tia_render_to(int target)
{
    if (target > TIA_CLOCKS_LINE) target = TIA_CLOCKS_LINE;
    int h = tia.rpos;
    if (h < TIA_HBLANK) h = TIA_HBLANK;
    if (target > h && (unsigned)tia.line < TIA_MAX_LINES) {
        uint8_t *row = tia.fb[tia.line];
        for (; h < target; h++) row[h - TIA_HBLANK] = draw_pixel(h - TIA_HBLANK);
    }
    if (target > tia.rpos) tia.rpos = target;
}

/* ------------------------------------------------------------------ */
/* Audio                                                               */
/* ------------------------------------------------------------------ */
static inline uint8_t lfsr4(uint8_t s) { return (uint8_t)(((s << 1) | (((s >> 3) ^ (s >> 2)) & 1)) & 0x0F); }
static inline uint8_t lfsr5(uint8_t s) { return (uint8_t)(((s << 1) | (((s >> 4) ^ (s >> 2)) & 1)) & 0x1F); }
static inline uint16_t lfsr9(uint16_t s) { return (uint16_t)(((s << 1) | (((s >> 8) ^ (s >> 3)) & 1)) & 0x1FF); }

static void audio_step(int ch)
{
    tia_audio_ch_t *c = &tia.ach[ch];
    switch (tia.audc[ch] & 15) {
    case 0: case 11: c->out = 1; break;
    case 1: c->p4 = lfsr4(c->p4); c->out = c->p4 & 1; break;
    case 2: c->d31 = (c->d31 + 1) % 31;
            if (c->d31 == 0) c->p4 = lfsr4(c->p4);
            c->out = c->p4 & 1; break;
    case 3: c->p5 = lfsr5(c->p5);
            if (c->p5 & 1) c->p4 = lfsr4(c->p4);
            c->out = c->p4 & 1; break;
    case 4: case 5: c->out ^= 1; break;
    case 6: case 10: c->d31 = (c->d31 + 1) % 31; c->out = c->d31 < 18; break;
    case 7: case 9:  c->p5 = lfsr5(c->p5); c->out = c->p5 & 1; break;
    case 8: c->p9 = lfsr9(c->p9); c->out = c->p9 & 1; break;
    case 12: case 13: if (++c->d3 >= 3) { c->d3 = 0; c->out ^= 1; } break;
    case 14: c->d31 = (c->d31 + 1) % 93; c->out = c->d31 < 47; break;
    case 15: if (++c->d3 >= 3) { c->d3 = 0; c->p5 = lfsr5(c->p5); c->out = c->p5 & 1; } break;
    }
}

static void audio_tick(void)
{
    for (int ch = 0; ch < 2; ch++) {
        tia_audio_ch_t *c = &tia.ach[ch];
        if (++c->cnt > (tia.audf[ch] & 31)) { c->cnt = 0; audio_step(ch); }
    }
    int v0 = tia.ach[0].out ? (tia.audv[0] & 15) : 0;
    int v1 = tia.ach[1].out ? (tia.audv[1] & 15) : 0;
    float x = (float)(v0 + v1) * 1000.0f;
    float y = x - tia.dc_x + 0.995f * tia.dc_y;      /* DC blocker */
    tia.dc_x = x; tia.dc_y = y;
    if (y > 32767.0f) y = 32767.0f;
    if (y < -32768.0f) y = -32768.0f;
    if (tia.an < TIA_AUDIO_BUF) tia.abuf[tia.an++] = (int16_t)y;
}

/* ------------------------------------------------------------------ */
/* Beam                                                                */
/* ------------------------------------------------------------------ */
static void finish_frame(void)
{
    int fv = tia.fv_cur;
    if (fv < 10 || fv > 100) fv = 36;
    tia.first_visible = fv;
    tia.fv_cur = 9999;
    tia.frame_ready = 1;
}

static void end_line(void)
{
    tia_render_to(TIA_CLOCKS_LINE);
    if (!(tia.vblank & 2) && tia.line >= 0 && tia.line < tia.fv_cur) tia.fv_cur = tia.line;
    tia.hpos -= TIA_CLOCKS_LINE;
    tia.rpos = 0;
    tia.hmove_blank = 0;
    tia.line++;
    if (tia.line >= TIA_MAX_LINES) { finish_frame(); tia.line = 0; }   /* runaway frame */
}

void tia_post_advance(void)
{
    while (tia.aclk >= 114) { tia.aclk -= 114; audio_tick(); }
    while (tia.hpos >= TIA_CLOCKS_LINE) end_line();
}

void tia_clocks(int n)
{
    tia.hpos += n;
    tia.aclk += n;
    tia_post_advance();
}

/* ------------------------------------------------------------------ */
/* Register access                                                     */
/* ------------------------------------------------------------------ */
void tia_reset(void)
{
    memset(&tia, 0, sizeof tia);
    tia.inpt4 = tia.inpt5 = 0x80;
    tia.first_visible = 36;
    tia.fv_cur = 9999;
    for (int i = 0; i < 2; i++) {
        tia.ach[i].p4 = 0x0F; tia.ach[i].p5 = 0x1F; tia.ach[i].p9 = 0x1FF;
    }
    rebuild_pf();
}

uint8_t tia_read(uint16_t reg)
{
    reg &= 0x0F;
    if (reg < 8) { tia_render_to(tia.hpos); return tia.cx[reg]; }
    if (reg == 0x0C) return tia.inpt4;
    if (reg == 0x0D) return tia.inpt5;
    return 0;      /* paddle inputs INPT0-3: not connected */
}

static inline int hm_signed(uint8_t hm) { int n = hm >> 4; return n < 8 ? n : n - 16; }

void tia_write(uint16_t reg, uint8_t v)
{
    reg &= 0x3F;
    if (reg == 0x02) { tia.wsync = 1; return; }
    tia_render_to(tia.hpos);

    switch (reg) {
    case 0x00:  /* VSYNC */
        if (!(v & 2) && (tia.vsync & 2)) { finish_frame(); tia.line = -1; }
        tia.vsync = v;
        break;
    case 0x01: tia.vblank = v; break;
    case 0x04: tia.nusiz[0] = v; break;
    case 0x05: tia.nusiz[1] = v; break;
    case 0x06: tia.colup[0] = v; break;
    case 0x07: tia.colup[1] = v; break;
    case 0x08: tia.colupf = v; break;
    case 0x09: tia.colubk = v; break;
    case 0x0A: tia.ctrlpf = v; rebuild_pf(); break;
    case 0x0B: tia.refp[0] = v; break;
    case 0x0C: tia.refp[1] = v; break;
    case 0x0D: tia.pf[0] = v; rebuild_pf(); break;
    case 0x0E: tia.pf[1] = v; rebuild_pf(); break;
    case 0x0F: tia.pf[2] = v; rebuild_pf(); break;

    /* position strobes */
    case 0x10: tia.ppos[0] = tia.hpos < TIA_HBLANK ? 3 : wrap160(tia.hpos - TIA_HBLANK + 5); break;
    case 0x11: tia.ppos[1] = tia.hpos < TIA_HBLANK ? 3 : wrap160(tia.hpos - TIA_HBLANK + 5); break;
    case 0x12: tia.mpos[0] = tia.hpos < TIA_HBLANK ? 2 : wrap160(tia.hpos - TIA_HBLANK + 4); break;
    case 0x13: tia.mpos[1] = tia.hpos < TIA_HBLANK ? 2 : wrap160(tia.hpos - TIA_HBLANK + 4); break;
    case 0x14: tia.bpos    = tia.hpos < TIA_HBLANK ? 2 : wrap160(tia.hpos - TIA_HBLANK + 4); break;

    /* audio */
    case 0x15: tia.audc[0] = v & 15; break;
    case 0x16: tia.audc[1] = v & 15; break;
    case 0x17: tia.audf[0] = v & 31; break;
    case 0x18: tia.audf[1] = v & 31; break;
    case 0x19: tia.audv[0] = v & 15; break;
    case 0x1A: tia.audv[1] = v & 15; break;

    /* graphics */
    case 0x1B: tia.grp[0] = v; tia.grp_old[1] = tia.grp[1]; break;
    case 0x1C: tia.grp[1] = v; tia.grp_old[0] = tia.grp[0]; tia.enabl_old = tia.enabl; break;
    case 0x1D: tia.enam[0] = v; break;
    case 0x1E: tia.enam[1] = v; break;
    case 0x1F: tia.enabl = v; break;

    /* fine motion */
    case 0x20: tia.hmp[0] = v; break;
    case 0x21: tia.hmp[1] = v; break;
    case 0x22: tia.hmm[0] = v; break;
    case 0x23: tia.hmm[1] = v; break;
    case 0x24: tia.hmbl = v; break;
    case 0x25: tia.vdelp[0] = v & 1; break;
    case 0x26: tia.vdelp[1] = v & 1; break;
    case 0x27: tia.vdelbl = v & 1; break;

    case 0x28: case 0x29: {   /* RESMP0/1 */
        int i = reg - 0x28;
        if ((tia.resmp[i] & 2) && !(v & 2)) {
            int nz = tia.nusiz[i] & 7;
            int c = (nz == 5) ? 8 : (nz == 7) ? 16 : 4;
            tia.mpos[i] = wrap160(tia.ppos[i] + c);
        }
        tia.resmp[i] = v;
        break;
    }
    case 0x2A:  /* HMOVE */
        for (int i = 0; i < 2; i++) {
            tia.ppos[i] = wrap160(tia.ppos[i] - hm_signed(tia.hmp[i]));
            tia.mpos[i] = wrap160(tia.mpos[i] - hm_signed(tia.hmm[i]));
        }
        tia.bpos = wrap160(tia.bpos - hm_signed(tia.hmbl));
        if (tia.hpos < TIA_HBLANK) tia.hmove_blank = 1;
        break;
    case 0x2B: tia.hmp[0] = tia.hmp[1] = tia.hmm[0] = tia.hmm[1] = tia.hmbl = 0; break;
    case 0x2C: memset(tia.cx, 0, sizeof tia.cx); break;
    default: break;
    }
}
